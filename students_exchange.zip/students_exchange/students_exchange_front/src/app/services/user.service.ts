import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

const BASIC_URL = ["http://localhost:8080"]

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  postUser(user : any): Observable<any>{
    return this.http.post(BASIC_URL+"/api/user",user)
  }

  getAllUser(): Observable<any> {
    return this.http.get(BASIC_URL+"/api/user");
  }

  getUserById(id:number): Observable<any> {
    return this.http.get(BASIC_URL+"/api/user/"+id);
  }

  deleteUser(id:number): Observable<any> {
    return this.http.delete(BASIC_URL+"/api/user/"+id);
  }

  updateUser(id:number, user: any): Observable<any> {
    return this.http.put(BASIC_URL+"/api/user/"+id, user);
  }
}
