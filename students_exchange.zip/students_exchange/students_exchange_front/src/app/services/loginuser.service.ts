import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../classes/user';

@Injectable({
  providedIn: 'root'
})
export class LoginuserService {
  private baseUrl="http://localhost:8080/api/login";
  constructor(private httpClient: HttpClient) { }

  login(user:User):Observable<User>{
    console.log(user)
    return this.httpClient.post<User>(`${this.baseUrl}`, user);

  }
}
