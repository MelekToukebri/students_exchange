export class User {
    fullName!:string;
    username!:string;
    password!:string;
    emailAdress!:string;
    contactNumber!:string;
    role!:string;
}
