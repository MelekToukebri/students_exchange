import { CanActivateFn } from '@angular/router';
import { inject } from '@angular/core';
import { Router } from '@angular/router';

export const adminGuard: CanActivateFn = (route, state) => {
  const router = inject(Router); // Inject the Router service

  // Retrieve the role from localStorage
  const userRole = localStorage.getItem('userRole');

  if (userRole === 'Admin' || userRole == 'admin') {
    // Allow access if the user is an admin
    return true;
  } else {
    // Redirect to home page if the user is not an admin
    alert('You do not have permission to access this page.');
    console.log(userRole);
    router.navigate(['/home']);
    return false;
  }
};
