import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PostUserComponent } from './components/post-user/post-user.component';
import { GetAllUsersComponent } from './components/get-all-users/get-all-users.component';
import { UpdateUserComponent } from './components/update-user/update-user.component';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { HomeComponent } from './components/home/home.component';
import { adminGuard } from './admin.guard'; 

const routes: Routes = [
  { path: '', redirectTo: 'user-login', pathMatch: 'full' },
  {path: 'user', component: PostUserComponent},
  {path: 'get-all-users', component: GetAllUsersComponent, canActivate: [adminGuard]},
  {path: 'user/:id', component: UpdateUserComponent},
  {path: 'user-login', component: UserLoginComponent},
  {path: 'home', component: HomeComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
