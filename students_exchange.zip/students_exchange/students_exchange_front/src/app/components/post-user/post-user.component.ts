import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-user',
  standalone: false,
  
  templateUrl: './post-user.component.html',
  styleUrl: './post-user.component.css'
})
export class PostUserComponent {
  
  postUserForm!: FormGroup;

  constructor(private userService:UserService,
     private fb:FormBuilder,
     private router : Router) {}
  ngOnInit(){
    this.postUserForm = this.fb.group({
      username:['', [Validators.required]],
      password:['', [Validators.required]],
      fullName:['', [Validators.required]],
      emailAddress:['', [Validators.required,Validators.email]],
      contactNumber:['', [Validators.required]],
      role:['', [Validators.required]],

    })
  }

  postUser(){
    console.log(this.postUserForm.value);
    this.userService.postUser(this.postUserForm.value).subscribe((res)=>{
      console.log(res);
      this.router.navigateByUrl("/get-all-users")
    })
  }

}
