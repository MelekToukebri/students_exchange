import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-user',
  standalone: false,
  templateUrl: './post-user.component.html',
  styleUrl: './post-user.component.css'
})
export class PostUserComponent {
  
  postUserForm!: FormGroup;
  allUsers: any[] = [];  // Array to store the list of all users

  constructor(
    private userService: UserService,
    private fb: FormBuilder,
    private router: Router
  ) {}

  ngOnInit() {
    this.postUserForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
      fullName: ['', [Validators.required]],
      emailAddress: ['', [Validators.required, Validators.email]],
      contactNumber: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      role: ['', [Validators.required]],
    });

    // Fetch all users when the component is initialized
    this.userService.getAllUser().subscribe((res) => {
      this.allUsers = res; // Store the users in the array
    });
  }

  postUser() {
    // Mark all controls as touched to trigger validation messages
    Object.keys(this.postUserForm.controls).forEach((field) => {
      const control = this.postUserForm.get(field);
      control?.markAsTouched();
    });

    // Check if the form is valid before proceeding
    if (this.postUserForm.invalid) {
      return;
    }

    // Check if the username or email already exists
    const usernameExists = this.allUsers.some(
      (user) => user.username === this.postUserForm.value.username
    );
    const emailExists = this.allUsers.some(
      (user) => user.emailAddress === this.postUserForm.value.emailAddress
    );

    // Set errors if the username or email exists
    if (usernameExists) {
      this.postUserForm.get('username')?.setErrors({ usernameExists: true });
    }

    if (emailExists) {
      this.postUserForm.get('emailAddress')?.setErrors({ emailExists: true });
    }

    // If either username or email already exists, don't submit the form
    if (usernameExists || emailExists) {
      console.log('Username or email already exists');
      return;
    }

    // If form is valid and there are no duplicates, proceed with the user creation
    console.log(this.postUserForm.value);
    this.userService.postUser(this.postUserForm.value).subscribe((res) => {
      console.log('User added successfully:', res);
      this.router.navigateByUrl('/get-all-users'); // Redirect to users list
    });
  }
}
