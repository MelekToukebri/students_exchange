import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-user',
  standalone: false,
  templateUrl: './update-user.component.html',
  styleUrl: './update-user.component.css'
})
export class UpdateUserComponent {
  updateUserForm!: FormGroup;
  id: number = this.activatedRoute.snapshot.params['id'];  // Ensure id is fetched before form logic
  allUsers: any[] = []; // Array to store the list of all users

  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private fb: FormBuilder,
    private router: Router
  ) {}

  ngOnInit() {
    // Initialize the form
    this.updateUserForm = this.fb.group({
      username: ['', [Validators.required]], // Disable username field
      password: ['', [Validators.required]],
      fullName: ['', [Validators.required]],
      emailAddress: ['', [Validators.required, Validators.email]],
      contactNumber: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      role: ['', [Validators.required]],
    });

    // Fetch all users when the component is initialized
    this.userService.getAllUser().subscribe((res) => {
      this.allUsers = res; // Store the users in the array
      this.getUserById(); // Fetch the user details for update after all users are loaded
    });
  }

  // Fetch the current user using ID
  getUserById() {
    this.userService.getUserById(this.id).subscribe((res) => {
      console.log('Fetched user:', res);
      this.updateUserForm.patchValue(res); // Pre-fill the form with current user data
      this.id = res.id; // Store the id in case it's not in the form but used for checks
    });
  }

  // Handle form submission
  updateUser() {
    // Ensure the id is available before continuing
    if (!this.id) {
      console.log('User ID is missing.');
      return;
    }

    // Mark all controls as touched to trigger validation messages
    Object.keys(this.updateUserForm.controls).forEach((field) => {
      const control = this.updateUserForm.get(field);
      control?.markAsTouched();
    });

    // Check if the form is valid before proceeding
    if (this.updateUserForm.invalid) {
      console.log("Form is invalid!");
      return;
    }

    // Get the current form values
    const { emailAddress, username } = this.updateUserForm.value;

    // Check if the email already exists (excluding the current user)
    const emailExists = this.allUsers.some(
      (user) => user.emailAddress === emailAddress && user.id !== this.id // Ensure the current user is excluded
    );

    // Check if the username already exists (excluding the current user)
    const usernameExists = this.allUsers.some(
      (user) => user.username === username && user.id !== this.id // Ensure the current user is excluded
    );

    // Set error if the email exists
    if (emailExists) {
      this.updateUserForm.get('emailAddress')?.setErrors({ emailExists: true });
      console.log("Email already exists, setting error.");
      return; // Don't proceed if email is already in use
    }

    // Set error if the username exists
    if (usernameExists) {
      this.updateUserForm.get('username')?.setErrors({ usernameExists: true });
      console.log("Username already exists, setting error.");
      return; // Don't proceed if username is already in use
    }

    // Manually add the ID to the updatedData object
    const updatedData = { ...this.updateUserForm.value, id: this.id };

    // Debug: Check what data is being sent for update
    console.log("Updated data with ID:", updatedData);

    // Make the update request
    this.userService.updateUser(this.id, updatedData).subscribe((res) => {
      console.log('User updated successfully:', res);
      if (res.id != null) {
        this.router.navigateByUrl('/get-all-users'); // Redirect to users list
      }
    });
  }
}
