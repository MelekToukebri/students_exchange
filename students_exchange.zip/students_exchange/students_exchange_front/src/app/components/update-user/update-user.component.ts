import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-user',
  standalone: false,
  
  templateUrl: './update-user.component.html',
  styleUrl: './update-user.component.css'
})
export class UpdateUserComponent {
  updateUserForm! : FormGroup;
  id: number = this.activatedRoute.snapshot.params["id"];

  constructor(private activatedRoute: ActivatedRoute,
    private userService: UserService,
  private fb: FormBuilder,
private router:Router) { }

  ngOnInit() {
    this.updateUserForm = this.fb.group({
      username:['', [Validators.required]],
      password:['', [Validators.required]],
      fullName:['', [Validators.required]],
      emailAddress:['', [Validators.required,Validators.email]],
      contactNumber:['', [Validators.required]],
      role:['', [Validators.required]],

    })
    this.getUserById();

  }

  

  getUserById() {
    this.userService.getUserById(this.id).subscribe((res)=>{
      console.log(res);
      this.updateUserForm.patchValue(res);

    })
  }

  updateUser(){
    this.userService.updateUser(this.id,this.updateUserForm.value).subscribe((res)=>{
      console.log(res);
      if(res.id!=null)
      {
        this.router.navigateByUrl("/get-all-users");
      }
    })
  }

}
