import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-get-all-users',
  standalone: false,
  
  templateUrl: './get-all-users.component.html',
  styleUrl: './get-all-users.component.css'
})
export class GetAllUsersComponent {

  users: any= [];

  constructor(private userService: UserService){}
    ngOnInit(){
      this.GetAllUsers();
    }
    GetAllUsers(){
      this.userService.getAllUser().subscribe((res)=>{
        console.log(res);
        this.users=res;
      })
    }
    deleteUser(id:number){
      this.userService.deleteUser(id).subscribe((res)=>{
        console.log(res);
        this.GetAllUsers();
      })
    }
  }



