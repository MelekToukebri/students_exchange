import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../classes/user';
import { LoginuserService } from '../../services/loginuser.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-login',
  standalone: false,
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  user: User = new User();
  loginForm!: FormGroup;

  constructor(
    private loginuserservice: LoginuserService,
    private router: Router,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    // Initialize the form with validation
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]], // username field with required validation
      password: ['', [Validators.required]]  // password field with required validation
    });
  }

  // Handle form submission
  userLogin() {
    if (this.loginForm.valid) {
      console.log(this.user);
      this.loginuserservice.login(this.loginForm.value).subscribe({
        next: (data) => {
          console.log('Login Successful:', data);
          console.log('User Role:', data?.role);
          if (data && data.role) {
            localStorage.setItem('userRole', data.role); // Save the role to localStorage
          }
          alert("Login Successful");
          this.router.navigate(['/home']);
        },
        error: (error) => {
          alert("Check Credentials");
        }
      });
    }
  }
}
