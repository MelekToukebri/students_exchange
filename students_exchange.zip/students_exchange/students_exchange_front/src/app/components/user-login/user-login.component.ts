import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../classes/user';
import { LoginuserService } from '../../services/loginuser.service';

@Component({
  selector: 'app-user-login',
  standalone: false,
  
  templateUrl: './user-login.component.html',
  styleUrl: './user-login.component.css'
})
export class UserLoginComponent implements OnInit{
  user:User = new User();

  constructor (private loginuserservice: LoginuserService, private router: Router) {}

  ngOnInit():void{

  }

  userLogin() {
    console.log(this.user);
    this.loginuserservice.login(this.user).subscribe({
      next: (data) => {
        alert("Login Successful");
        this.router.navigate(['/home']);
      },
      error: (error) => {
        alert("Check Credentials");
      }
    });
  }

}
