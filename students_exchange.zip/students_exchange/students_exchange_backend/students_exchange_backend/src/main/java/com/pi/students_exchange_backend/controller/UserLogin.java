package com.pi.students_exchange_backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pi.students_exchange_backend.entity.User;
import com.pi.students_exchange_backend.repository.UserRepository;
import com.pi.students_exchange_backend.service.UserService;

import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class UserLogin {

    @Autowired
    private UserRepository repo;

    @Autowired UserService userService;

    @PostMapping("/login")
public ResponseEntity<User> loginUser(@RequestBody User userData) {
    System.out.println(userData);

    User user = repo.findByUsername(userData.getUsername());

    if (user != null && user.getPassword().equals(userData.getPassword())) {
        return ResponseEntity.ok(user);
    } else {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null); // Or return an error message
    }
}

}
