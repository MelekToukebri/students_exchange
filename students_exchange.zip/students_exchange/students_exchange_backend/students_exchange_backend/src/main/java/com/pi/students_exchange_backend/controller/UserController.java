package com.pi.students_exchange_backend.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pi.students_exchange_backend.entity.User;
import com.pi.students_exchange_backend.service.UserService;

import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;


@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@CrossOrigin("*")
public class UserController {

    private final UserService userService;
    
    @PostMapping("/user")
    public User postUser(@RequestBody User user){
        return userService.postUser(user);
    }

    @GetMapping("/user")
    private List<User> getAllUser(){
        return userService.getAllUser();
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id){
        User user = userService.getUserById(id);
        if (user== null)
            return ResponseEntity.notFound().build();
        return ResponseEntity.ok(user);
    } 
    @DeleteMapping("/user/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        User existingUser = userService.getUserById(id);
        if (existingUser == null)
            return ResponseEntity.notFound().build();
        userService.deleteUser(id);
        return ResponseEntity.ok().build();

    }

    @PutMapping("/user/{id}")
    public ResponseEntity <User> updateUser(@PathVariable Long id, @RequestBody User user){
        User existingUser = userService.getUserById(id);
        if(existingUser == null)
        return ResponseEntity.notFound().build();
        existingUser.setUsername(user.getUsername());
        existingUser.setPassword(user.getPassword());
        existingUser.setFullName(user.getFullName());
        existingUser.setEmailAddress(user.getEmailAddress());
        existingUser.setContactNumber(user.getContactNumber());
        existingUser.setRole(user.getRole());
        User updateUser = userService.updateUser(existingUser);
        return ResponseEntity.ok(updateUser);

    }

}
