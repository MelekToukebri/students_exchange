package com.pi.students_exchange_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsExchangeBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
